const todoList = [];

module.exports = todoList;